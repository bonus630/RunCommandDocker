﻿Imports Corel.Interop.VGCore
Imports System.Windows.Forms


<System.AttributeUsage(System.AttributeTargets.[Class])>
    Public Class CgsAddInModule
        Inherits System.Attribute
    End Class

    <System.AttributeUsage(System.AttributeTargets.Constructor)>
    Public Class CgsAddInConstructor
        Inherits System.Attribute
    End Class

    <System.AttributeUsage(System.AttributeTargets.Method)>
    Public Class CgsAddInMacro
        Inherits System.Attribute
    End Class

    <CgsAddInModule>
    Public Class Class1

    'Commented code dont works!
    'Private app As Corel.Interop.VGCore.Application
    '<CgsAddInConstructor>
    'Sub New(ByVal app As Corel.Interop.VGCore.Application)
    'Me.app = app
    'End Sub


    Private app As Object

    <CgsAddInConstructor>
    Sub New(ByVal app As Object)
        Me.app = app
    End Sub

    <CgsAddInMacro>
    Sub NewDoc()
        Me.app.CreateDocument()
    End Sub
 
End Class

