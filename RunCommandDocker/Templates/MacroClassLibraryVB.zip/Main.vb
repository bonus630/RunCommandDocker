﻿    <CgsAddInModule>
    <ModulePath("$ModulePath$")>
    Public Class Main

    'Commented code dont works!
    'Private app As Corel.Interop.VGCore.Application
    '<CgsAddInConstructor>
    'Sub New(ByVal app As Corel.Interop.VGCore.Application)
    'Me.app = app
    'End Sub


    Private corelApp As Object

    <CgsAddInConstructor>
    Sub New(ByVal app As Object)
        corelApp = app
    End Sub

    <CgsAddInMacro>
    Sub NewDocument()
        corelApp.CreateDocument()
    End Sub
 
End Class

